# ADS1256
ADS1256 for ESP32

Based on Teensy libraray for ADS1256  based on the demo found here: https://forum.pjrc.com/threads/49404-TI-ADS1256-8-CH-24-bit-A-D
